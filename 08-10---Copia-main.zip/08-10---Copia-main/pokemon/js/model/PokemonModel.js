export class PokemonModel {
    constructor(service) {
        this.service = service;
        this.pokemons = []; // Lista de pokémons
        this.selectedPokemon = null; // Detalhes do pokémon selecionado
    }

    /**
     * Busca e armazena a lista de pokémons.
     */
    async fetchPokemons(limit, offset) {
        const data = await this.service.getPokemons(limit, offset);
        
        this.pokemons = data.results.map(p => {
            // Extrai o ID da URL (ex: "https://pokeapi.co/api/v2/pokemon/1/" -> "1")
            const urlParts = p.url.split('/');
            const id = urlParts[urlParts.length - 2];
            
            return {
                name: p.name,
                url: p.url,
                id: id,
                // Monta a URL da imagem do card
                imageUrl: `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${id}.png`
            };
        });
        return this.pokemons;
    }

    /**
     * Busca e armazena os detalhes de um pokémon.
     */
    async fetchPokemonDetails(nameOrId) {
        const data = await this.service.getPokemonByNameOrId(nameOrId);
        this.selectedPokemon = this._formatPokemonData(data);
        return this.selectedPokemon;
    }

    /**
     * Helper privado para formatar os dados da API em uma estrutura amigável.
     */
    _formatPokemonData(apiData) {
        return {
            id: apiData.id,
            name: apiData.name,
            imageUrl: apiData.sprites.front_default || 'path/to/default/image.png',
            types: apiData.types.map(typeInfo => typeInfo.type.name),
            stats: apiData.stats.map(statInfo => ({
                name: statInfo.stat.name.replace('special-attack', 'sp. atk').replace('special-defense', 'sp. def'),
                value: statInfo.base_stat
            }))
        };
    }
}