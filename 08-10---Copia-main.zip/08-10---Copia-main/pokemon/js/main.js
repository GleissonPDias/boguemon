import { PokemonService } from './service/PokemonService.js';
import { PokemonModel } from './model/PokemonModel.js';
import { PokemonView } from './view/PokemonView.js';
import { PokemonController } from './controller/PokemonController.js';

// 1. Cria as instâncias
const service = new PokemonService();
const model = new PokemonModel(service);
const view = new PokemonView();

// 2. Injeta as dependências no Controller
const controller = new PokemonController(model, view);

// 3. Inicia a aplicação
controller.init();