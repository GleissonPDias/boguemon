export class PokemonView {
    constructor() {
        // Mapeamento dos elementos do DOM
        this.pokemonList = document.getElementById('pokemon-list');
        this.detailsCard = document.getElementById('pokemon-details-card');
        this.searchForm = document.getElementById('search-form');
        this.searchInput = document.getElementById('search-input');
    }

    /**
     * Renderiza a lista de pokémons (Moléculas) no organismo da lista.
     */
    renderPokemonList(pokemons) {
        this.pokemonList.innerHTML = ''; // Limpa o grid
        pokemons.forEach(pokemon => {
            // Usamos <li> como item do grid para manter a semântica do <ul>
            const card = document.createElement('li'); 
            card.className = 'pokemon-card-molecule';
            card.dataset.name = pokemon.name; // Para o event listener
            
            card.innerHTML = `
                <img src="${pokemon.imageUrl}" alt="${pokemon.name}" class="img-atom-card">
                <p class="name-atom-card">${pokemon.name}</p>
            `;
            
            this.pokemonList.appendChild(card);
        });
    }

    /**
     * Renderiza os detalhes de um pokémon (Átomos e Moléculas) no cartão.
     */
    renderPokemonDetails(pokemon) {
        const typesHtml = pokemon.types.map(type => 
            `<span class="type-badge-atom type-${type}">${type}</span>`
        ).join(' ');

        const statsHtml = pokemon.stats.map(stat => `
            <div class="stat-display-molecule">
                <span class="stat-name-atom">${stat.name}</span>
                <span class="stat-value-atom">${stat.value}</span>
                <div class="stat-bar-atom">
                    <div class="stat-bar-inner-atom" style="width: ${Math.min(stat.value, 150) / 1.5}%;"></div>
                </div>
            </div>
        `).join('');

        this.detailsCard.innerHTML = `
            <img src="${pokemon.imageUrl}" alt="${pokemon.name}" class="img-atom">
            <h3>#${pokemon.id} - ${pokemon.name}</h3>
            <div class="types-container">${typesHtml}</div>
            <div class="stats-container">${statsHtml}</div>
        `;
    }

    /**
     * Exibe uma mensagem de carregamento ou estado inicial.
     */
    showPlaceholder(message) {
        this.detailsCard.innerHTML = `<p>${message}</p>`;
    }

    /**
     * Exibe uma mensagem de erro no cartão de detalhes.
     */
    showError(message) {
        this.detailsCard.innerHTML = `<p class="error">${message}</p>`;
    }

    /**
     * Vincula o evento de submit do formulário de busca a um handler (do Controller).
     */
    bindSearchSubmit(handler) {
        this.searchForm.addEventListener('submit', event => {
            event.preventDefault();
            const searchTerm = this.searchInput.value.trim();
            if (searchTerm) {
                handler(searchTerm);
                this.searchInput.value = ''; // Limpa o input
            }
        });
    }

    /**
     * Vincula o evento de clique na lista de pokémons a um handler (do Controller).
     * Usa delegação de eventos.
     */
    bindPokemonClick(handler) {
        this.pokemonList.addEventListener('click', event => {
            const cardItem = event.target.closest('.pokemon-card-molecule');
            if (cardItem) {
                const pokemonName = cardItem.dataset.name;
                handler(pokemonName);
            }
        });
    }
}