export class PokemonController {
    constructor(model, view) {
        this.model = model;
        this.view = view;
    }

    /**
     * Inicializa a aplicação.
     */
    async init() {
        // Vincula os handlers da View aos métodos do Controller
        this.view.bindSearchSubmit(this.handleSearch.bind(this));
        this.view.bindPokemonClick(this.handleSelectPokemon.bind(this));

        // Carrega a lista inicial
        await this.loadInitialPokemons();
    }

    /**
     * Carrega a lista inicial de pokémons.
     */
    async loadInitialPokemons() {
        try {
            this.view.showPlaceholder("Carregando lista...");
            const pokemons = await this.model.fetchPokemons(50, 0);
            this.view.renderPokemonList(pokemons);
            this.view.showPlaceholder("Selecione um Pokémon da lista ou faça uma busca.");
        } catch (error) {
            this.view.showError("Falha ao carregar lista de Pokémons.");
        }
    }

    /**
     * Handler para o evento de busca.
     */
    async handleSearch(nameOrId) {
        try {
            this.view.showPlaceholder(`Buscando "${nameOrId}"...`);
            const pokemon = await this.model.fetchPokemonDetails(nameOrId);
            this.view.renderPokemonDetails(pokemon);
        } catch (error) {
            this.view.showError(`Pokémon "${nameOrId}" não encontrado.`);
        }
    }

    /**
     * Handler para o evento de clique na lista.
     */
    async handleSelectPokemon(name) {
        // Reutiliza a lógica de busca
        await this.handleSearch(name);
    }
}