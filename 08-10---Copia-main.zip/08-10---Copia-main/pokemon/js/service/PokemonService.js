export class PokemonService {
    constructor() {
        this.baseURL = 'https://pokeapi.co/api/v2/';
    }

    /**
     * Busca uma lista de pokémons com paginação.
     */
    async getPokemons(limit = 50, offset = 0) {
        const url = `${this.baseURL}pokemon?limit=${limit}&offset=${offset}`;
        return this._fetchJSON(url);
    }

    /**
     * Busca um pokémon específico pelo nome ou ID.
     */
    async getPokemonByNameOrId(nameOrId) {
        if (!nameOrId) throw new Error("Nome ou ID do Pokémon é necessário.");
        const url = `${this.baseURL}pokemon/${nameOrId.toString().toLowerCase()}`;
        return this._fetchJSON(url);
    }

    /**
     * Função helper privada para requisições fetch.
     */
    async _fetchJSON(url) {
        try {
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error(`Erro na API: ${response.status} ${response.statusText}`);
            }
            return await response.json();
        } catch (error) {
            console.error("Falha na requisição do serviço:", error);
            throw error; // Propaga o erro para a camada que chamou (Model)
        }
    }
}